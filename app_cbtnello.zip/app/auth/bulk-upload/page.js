import BulkUserUpload from './BulkUserUploads';

export default function BulkUploadPage() {
  return (
    <div>
      <h1>Bulk User Upload</h1>
      <BulkUserUpload />
    </div>
  );
}
