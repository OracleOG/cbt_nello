// app/api/tests/[testId]/init/route.js
import { NextResponse } from "next/server";
import { auth } from "@/auth";
import prisma from "@/lib/prisma";

export async function POST(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const testId = Number(params.testId);
    
    // Check existing attempt
    const existingAttempt = await prisma.testTaker.findFirst({
      where: {
        userId: session.user.id,
        testId,
        completedAt: null
      }
    });

    if (existingAttempt) {
      return NextResponse.json({
        resumed: true,
        attemptId: existingAttempt.id,
        timeRemaining: existingAttempt.timeRemaining,
        answers: existingAttempt.answers
      });
    }

    // Create new attempt
    const newAttempt = await prisma.testTaker.create({
      data: {
        userId: session.user.id,
        testId,
        startedAt: new Date(),
        answers: {},
        timeRemaining: 300 // 5 minutes default
      }
    });

    return NextResponse.json({
      resumed: false,
      attemptId: newAttempt.id,
      timeRemaining: newAttempt.timeRemaining
    });

  } catch (error) {
    console.error("Init error:", error);
    return NextResponse.json(
      { error: "Failed to initialize test", details: error.message },
      { status: 500 }
    );
  }
}